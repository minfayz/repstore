const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  PermissionsBitField,
  AttachmentBuilder
} = require('discord.js');
const fs = require('fs');
const path = require('path');
const { CategoryTicketId, SELLER_ROLE_ID, ChannelLogTicketId } = require('../config.json');
const ticketPath = path.join(__dirname, '../data/tickets.json');

const loadTicketData = () => {
  if (!fs.existsSync(ticketPath)) return {};
  return JSON.parse(fs.readFileSync(ticketPath, 'utf-8'));
};

const saveTicketData = (data) => {
  fs.writeFileSync(ticketPath, JSON.stringify(data, null, 2));
};

module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    if (!interaction.isButton()) return;

    const { customId, guild, user, channel } = interaction;
    const ticketData = loadTicketData();

    if (customId === 'panggil_seller') {
      return interaction.reply({
        content: `🔔 <@&${SELLER_ROLE_ID}> telah dipanggil oleh <@${user.id}>.`,
        ephemeral: false
      });
    }

    if (customId === 'create_ticket') {
      if (ticketData[user.id]) {
        return interaction.reply({ content: '❌ Kamu sudah memiliki tiket!', ephemeral: true });
      }

      const ticketName = `ticket-${user.username.toLowerCase()}`;
      const randomId = Math.floor(1000 + Math.random() * 9000);

      const ticketChannel = await guild.channels.create({
        name: ticketName,
        type: ChannelType.GuildText,
        parent: CategoryTicketId,
        permissionOverwrites: [
          { id: guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
          { id: user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] },
          { id: SELLER_ROLE_ID, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] }
        ]
      });

      const ticketEmbed = new EmbedBuilder()
        .setTitle('🎟️ Ticket Support')
        .setDescription('Terima kasih telah menghubungi support. Harap tunggu respon dari tim kami.')
        .addFields(
          { name: 'ID Ticket', value: `${randomId}`, inline: true },
          { name: 'Dibuat Oleh', value: `<@${user.id}>`, inline: true }
        )
        .setColor('Green');

      const actionRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('panggil_seller')
          .setLabel('🔔 Panggil Seller')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('close_ticket')
          .setLabel('❌ Close Ticket')
          .setStyle(ButtonStyle.Danger)
      );

      await ticketChannel.send({ content: `<@${user.id}>`, embeds: [ticketEmbed], components: [actionRow] });
      await interaction.reply({ content: `✅ Ticket berhasil dibuat: ${ticketChannel}`, ephemeral: true });

      ticketData[user.id] = {
        channelId: ticketChannel.id,
        idTicket: randomId,
        userId: user.id
      };
      saveTicketData(ticketData);

      const logChannel = guild.channels.cache.get(ChannelLogTicketId);
      if (logChannel) {
        const openEmbed = new EmbedBuilder()
          .setTitle('📥 Ticket Dibuka')
          .addFields(
            { name: 'Nama Ticket', value: ticketChannel.name, inline: true },
            { name: 'User', value: `<@${user.id}>`, inline: true },
            { name: 'ID Ticket', value: `${randomId}`, inline: true }
          )
          .setColor('Blue')
          .setTimestamp();
        logChannel.send({ embeds: [openEmbed] });
      }
    }

    if (customId === 'close_ticket') {
      await interaction.reply({ content: '📪 Menutup ticket dalam 5 detik...', ephemeral: true });

      const ticketOwner = Object.keys(ticketData).find(key => ticketData[key].channelId === channel.id);
      const ticketInfo = ticketData[ticketOwner];

      setTimeout(async () => {
        const messages = await channel.messages.fetch({ limit: 100 });
        const content = messages
          .reverse()
          .map(m => `[${m.createdAt.toLocaleString()}] ${m.author.tag}: ${m.content}`)
          .join('\n');

        const transcriptFile = new AttachmentBuilder(Buffer.from(content), { name: `${channel.name}-transcript.txt` });

        const owner = await interaction.client.users.fetch(ticketOwner).catch(() => null);
        if (owner) {
          await owner.send({
            content: `📄 Berikut transcript ticket kamu (${channel.name}):`,
            files: [transcriptFile]
          }).catch(() => null);
        }

        const logChannel = guild.channels.cache.get(ChannelLogTicketId);
        if (logChannel) {
          const closeEmbed = new EmbedBuilder()
            .setTitle('📪 Ticket Ditutup')
            .addFields(
              { name: 'Nama Ticket', value: `${channel.name}`, inline: true },
              { name: 'User', value: `<@${ticketOwner}>`, inline: true },
              { name: 'Ditutup Oleh', value: `<@${user.id}>`, inline: true }
            )
            .setColor('Red')
            .setTimestamp();
          logChannel.send({ embeds: [closeEmbed] });
        }

        delete ticketData[ticketOwner];
        saveTicketData(ticketData);
        await channel.delete().catch(() => null);
      }, 5000);
    }
  }
};
