const { EmbedBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;
  
    if (['dana', 'gopay','ovo', 'qris'].includes(interaction.customId)) {
      let embed;
  
      switch (interaction.customId) {
        case 'dana':
          embed = new EmbedBuilder()
            .setTitle('DANA')
            .setDescription('**Silahkan transfer ke nomor di bawah ini sertakan bukti transfer**\nNOMOR: ```081228573019```')
            .setColor(0xf7ff00);
          break;
          
        case 'gopay':
          embed = new EmbedBuilder()
            .setTitle('GOPAY')
            .setDescription('**Silahkan transfer ke nomor di bawah ini sertakan bukti transfer**\nNOMOR: ```081228573019```')
            .setColor(0xf7ff00);
          break;

        case 'ovo':
            embed = new EmbedBuilder()
              .setTitle('OVO')
              .setDescription('**Silahkan transfer ke nomor di bawah ini sertakan bukti transfer**\nNOMOR: ```kosong```')
              .setColor(0xf7ff00);
            break;
    
        case 'qris':
          embed = new EmbedBuilder()
            .setTitle('QRIS')
            .setDescription('**A/N TOKO MINFAYZ**\nQris All Payment')
            .setColor(0xf7ff00)
            .setImage('https://cdn.discordapp.com/attachments/1430399190751772775/1431522272304169032/IMG-20251025-WA0007.jpg?ex=68fdb882&is=68fc6702&hm=a882a666280146ee2e40a22288d17309874b297b0795ca5d947de79874f695ab&');
          break;
      }
  
      await interaction.reply({
        embeds: [embed],
        ephemeral: true
      });
    }
  });
  