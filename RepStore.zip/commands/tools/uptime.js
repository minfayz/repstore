const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('uptime')
    .setDescription('Menampilkan lama bot sudah online'),

  async execute(interaction) {
    const totalSeconds = Math.floor(process.uptime());
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor(totalSeconds / 3600) % 24;
    const minutes = Math.floor(totalSeconds / 60) % 60;
    const seconds = totalSeconds % 60;

    const uptimeString = `${days} hari, ${hours} jam, ${minutes} menit, ${seconds} detik`;

    const embed = new EmbedBuilder()
      .setTitle('📊 Uptime Bot')
      .setDescription(`Bot telah online selama:\n**${uptimeString}**`)
      .setColor('Blue')
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
