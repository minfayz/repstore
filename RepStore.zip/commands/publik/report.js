const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const data = require('../../data/reportlog.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('report')
    .setDescription('Laporkan seseorang ke admin')
    .addUserOption(option =>
      option.setName('pelaku').setDescription('User yang dilaporkan').setRequired(true))
    .addStringOption(option =>
      option.setName('alasan').setDescription('Alasan melaporkan').setRequired(true))
    .addAttachmentOption(option =>
      option.setName('bukti').setDescription('Bukti gambar').setRequired(true)),

  async execute(interaction) {
    const pelapor = interaction.user;
    const pelaku = interaction.options.getUser('pelaku');
    const alasan = interaction.options.getString('alasan');
    const bukti = interaction.options.getAttachment('bukti');
    let logChannel;
    try {
      logChannel = await interaction.client.channels.fetch(data.channelId);
    } catch (err) {
      console.error('[REPORT ERROR] Gagal fetch channel:', err);
      return interaction.reply({ content: '❌ Channel log tidak ditemukan atau bot tidak punya akses.', ephemeral: true });
    }
        if (!logChannel) return interaction.reply({ content: '❌ Channel log tidak ditemukan.', ephemeral: true });

    const embed = new EmbedBuilder()
      .setTitle('📩 Report Masuk')
      .addFields(
        { name: 'Pelapor', value: `<@${pelapor.id}>`, inline: true },
        { name: 'Pelaku', value: `<@${pelaku.id}>`, inline: true },
        { name: 'Alasan', value: alasan }
      )
      .setColor('Red')
      .setTimestamp();

      if (bukti) {
        embed.setImage(`attachment://${bukti.name}`);
      }

    const button = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`jawab_${pelapor.id}`)
        .setLabel('Jawab Report')
        .setStyle(1)
    );

    await interaction.deferReply({ ephemeral: true });

    if (bukti) {
        embed.setImage(`attachment://${bukti.name}`);
        await logChannel.send({ embeds: [embed], components: [button], files: [bukti] });
      } else {
        await logChannel.send({ embeds: [embed], components: [button] });
      }      
    
    await interaction.editReply({ content: '✅ Report kamu telah dikirim ke admin.' });
    
  }
};
