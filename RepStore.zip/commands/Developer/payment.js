const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const config = require('../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('payment')
    .setDescription('Memilih metode pembayaran'),

  async execute(interaction) {
    if (!config.developerIds.includes(interaction.user.id)) {
      return interaction.reply({
        content: '❌ Kamu tidak memiliki akses ke perintah ini.',
        ephemeral: true
      });
    }

    const embed = new EmbedBuilder()
      .setTitle('PAYMENT')
      .setDescription('Silakan pilih salah satu metode pembayaran di bawah ini:')
      .setColor(0xf7ff00)
      .setImage('https://media1.tenor.com/images/b3b66ace65470cba241193b62366dfee/tenor.gif');

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('dana')
        .setLabel('DANA')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('gopay')
        .setLabel('GOPAY')
        .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
        .setCustomId('ovo')
        .setLabel('OVO')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('qris')
        .setLabel('QRIS')
        .setStyle(ButtonStyle.Primary)
    );

    await interaction.reply({
      embeds: [embed],
      components: [buttons]
    });
  }
};
