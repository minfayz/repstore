const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { TESTIMONI_CHANNEL_ID, SELLER_ROLE_ID } = require('../../config.json'); // sesuaikan path kalau beda

module.exports = {
  data: new SlashCommandBuilder()
    .setName('testimoni')
    .setDescription('Kirim testimoni pembeli')
    .addIntegerOption(option =>
      option.setName('nomor')
        .setDescription('Nomor testimoni ke berapa')
        .setRequired(true))
    .addUserOption(option =>
      option.setName('pembeli')
        .setDescription('Mention pembeli')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('harga')
        .setDescription('Harga produk')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('produk')
        .setDescription('Nama produk yang dibeli')
        .setRequired(true))
    .addAttachmentOption(option =>
      option.setName('bukti')
        .setDescription('Bukti pembelian (opsional)')),

  async execute(interaction) {
    if (!interaction.member.roles.cache.has(SELLER_ROLE_ID)) {
      return interaction.reply({
        content: 'Kamu tidak memiliki izin untuk menggunakan perintah ini.',
        ephemeral: true
      });
    }

    const nomor = interaction.options.getInteger('nomor');
    const pembeli = interaction.options.getUser('pembeli');
    const harga = interaction.options.getInteger('harga');
    const produk = interaction.options.getString('produk');
    const bukti = interaction.options.getAttachment('bukti');

    const embed = new EmbedBuilder()
      .setColor('#00ff00')
      .setTitle(`💳 Testimoni Ke #${nomor} | Fazmuir Store`)
      .addFields(
        { name: '🏪 Penjual', value: `<@${interaction.user.id}>`, inline: true },
        { name: '🛍 Pembeli', value: `<@${pembeli.id}>`, inline: true },
        { name: '💰 Harga', value: `Rp ${harga}`, inline: true },
        { name: '📦 Produk', value: produk, inline: false }
      )
      .setTimestamp()
      .setFooter({ text: `Fazmuir Store` });

    if (bukti) embed.setImage(bukti.url);

    const channel = interaction.client.channels.cache.get(TESTIMONI_CHANNEL_ID);
    if (!channel) {
      return interaction.reply({
        content: 'Channel testimoni tidak ditemukan.',
        ephemeral: true
      });
    }

    await channel.send({ embeds: [embed] });
    await interaction.reply({
      content: 'Testimoni berhasil dikirim!',
      ephemeral: true
    });
  }
};
