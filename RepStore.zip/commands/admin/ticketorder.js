const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const path = require('path');
const { ADMIN_ROLE_ID } = require(path.join(__dirname, '../../config.json'));

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticketorder')
    .setDescription('Menampilkan panel ticket untuk order.'),

  async execute(interaction) {
    if (!interaction.member.roles.cache.has(ADMIN_ROLE_ID)) {
      return interaction.reply({
        content: 'Kamu tidak memiliki izin untuk menjalankan perintah ini.',
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setTitle('🎟️ Ticket Order')
      .setDescription('Klik tombol di bawah untuk melakukan pembelian produk\n\n_Dilarang mempermainkan ticket_')
      .setColor('Blue');

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('create_ticket')
        .setLabel('Order')
        .setStyle(ButtonStyle.Primary)
    );

    await interaction.reply({ embeds: [embed], components: [row] });
  },
};
