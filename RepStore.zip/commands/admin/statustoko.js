const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('statustoko')
    .setDescription('Mengubah status toko menjadi buka atau tutup')
    .addStringOption(option =>
      option.setName('status')
        .setDescription('Status toko')
        .setRequired(true)
        .addChoices(
          { name: 'Buka', value: 'open' },
          { name: 'Tutup', value: 'close' }
        )
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator), // hanya admin

  async execute(interaction) {
    const status = interaction.options.getString('status');
    const member = interaction.member;
    const ADMIN_ROLE_ID = config.ADMIN_ROLE_ID;

    // Cek apakah user punya role admin
    if (!member.roles.cache.has(ADMIN_ROLE_ID)) {
      return interaction.reply({ content: '❌ Kamu tidak memiliki izin untuk menggunakan command ini.', ephemeral: true });
    }

    const isOpen = status === 'open';

    const embed = new EmbedBuilder()
      .setTitle(isOpen ? '🟢 TOKO BUKA' : '🔴 TOKO TUTUP')
      .setDescription(isOpen
        ? 'TOKO SUDAH BUKA, BAGI YG INGIN ORDER SILAHKAN PM / CREATE TICKET.'
        : 'TOKO TELAH DITUTUP UNTUK SEMENTARA. SILAKAN TUNGGU INFO SELANJUTNYA.')
      .setImage(isOpen
        ? 'https://cdn.discordapp.com/attachments/1202960266749284384/1293493023141003327/standard.gif'
        : 'https://cdn.discordapp.com/attachments/1202960266749284384/1293493022788554806/standard_1.gif')
      .setColor(isOpen ? 'Green' : 'Red')
      .setFooter({ text: 'RepStore' })
      .setTimestamp();

    await interaction.channel.send({
      content: '@everyone',
      embeds: [embed],
      allowedMentions: { parse: ['everyone'] }
    });

    await interaction.reply({
      content: `✅ Toko berhasil ${isOpen ? 'dibuka' : 'ditutup'}!`,
      ephemeral: true
    });
  }
};
