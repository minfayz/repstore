const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { BUYER_ROLE_ID, RATING_CHANNEL_ID } = require('../../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rating')
    .setDescription('Berikan rating untuk penjual.')
    .addUserOption(option =>
      option.setName('penjual')
        .setDescription('User penjual')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('harga')
        .setDescription('Harga transaksi')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('produk')
        .setDescription('Nama produk')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('rating')
        .setDescription('Beri rating dari 1 sampai 5')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(5))
    .addStringOption(option =>
      option.setName('ulasan')
        .setDescription('Tulis ulasan (opsional)')),

  async execute(interaction) {
    if (!interaction.member.roles.cache.has(BUYER_ROLE_ID)) {
      return interaction.reply({ content: 'Anda tidak memiliki izin untuk menggunakan perintah ini.', ephemeral: true });
    }

    const seller = interaction.options.getUser('penjual');
    const price = interaction.options.getInteger('harga');
    const product = interaction.options.getString('produk');
    const rating = interaction.options.getInteger('rating');
    const review = interaction.options.getString('ulasan') || 'Tidak ada ulasan.';
    const stars = '⭐'.repeat(rating) + '☆'.repeat(5 - rating);

    const embed = new EmbedBuilder()
      .setColor('#ffd700')
      .setTitle('⭐ Rating Seller | RepStore')
      .addFields(
        { name: '🏪 Penjual', value: `<@${seller.id}>`, inline: true },
        { name: '🛍 Pembeli', value: `<@${interaction.user.id}>`, inline: true },
        { name: '💰 Harga', value: `Rp ${price}`, inline: true },
        { name: '📦 Produk', value: product, inline: false },
        { name: '✨ Rating', value: stars, inline: true },
        { name: '💬 Ulasan', value: review, inline: false }
      )
      .setTimestamp()
      .setFooter({ text: `RepStore` });

    const channel = interaction.guild.channels.cache.get(RATING_CHANNEL_ID);
    if (!channel) {
      return interaction.reply({ content: 'Channel rating tidak ditemukan.', ephemeral: true });
    }

    await channel.send({ embeds: [embed] });
    await interaction.reply({ content: 'Rating berhasil dikirim!', ephemeral: true });
  }
};
